import { FiUser, FiBookOpen, FiMonitor, FiActivity } from "react-icons/fi"; // Import the icons

export const featuresData = [
  {
    id: 1,
    title: "معلمون محترفون",
    content: "تعلم من معلمين ذوي خبرة ومؤهلين في مجالاتهم.",
    icon: FiUser, // Use the imported icon
  },
  {
    id: 2,
    title: "دورات متنوعة",
    content:
      "استكشف مجموعة واسعة من الدورات التي تلبي احتياجات الطلاب المختلفة.",
    icon: FiBookOpen, // Use the imported icon
  },
  {
    id: 3,
    title: "تعليم مرن",
    content: "يمكنك الوصول إلى الدورات في أي وقت ومن أي مكان.",
    icon: FiMonitor, // Use the imported icon
  },
  {
    id: 4,
    title: "محتوى تفاعلي",
    content: "شارك في محتوى متعدد الوسائط واختبارات لتعزيز تجربتك التعليمية.",
    icon: FiActivity, // Use the imported icon
  },
];
