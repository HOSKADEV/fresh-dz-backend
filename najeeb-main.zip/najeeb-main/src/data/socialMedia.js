import { FaFacebookSquare } from "react-icons/fa";
import { FaInstagramSquare } from "react-icons/fa";
import { FaTwitterSquare } from "react-icons/fa";
import { FaWhatsappSquare } from "react-icons/fa";

export const socialMedia = [
  {
    name: "Facebook",
    icon: <FaFacebookSquare size={28} className="text-[#1877F2]" />, // Updated icon and color
    url: "https://www.facebook.com/SoufAcademy",
  },
  {
    name: "Instagram",
    icon: <FaInstagramSquare size={28} className="text-[#C13584]" />, // Subtle Instagram color (more towards purple)
    url: "https://www.instagram.com/soufacademy/",
  },
  {
    name: "Twitter",
    icon: <FaTwitterSquare size={28} className="text-[#1DA1F2]" />, // Updated to Twitter's official blue
    url: "#",
  },
  {
    name: "WhatsApp",
    icon: <FaWhatsappSquare size={28} className="text-[#25D366]" />, // More vibrant WhatsApp green
    url: "#",
  },
];
