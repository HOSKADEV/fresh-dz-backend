import React from "react";
function Footer() {
  return (
    <footer className="mt-16 py-8 border-t border-border-gray ">
      <div className="myContainer flex justify-center ">
        <p className="text-center text-secondary">
          {/* © {new Date().getFullYear()} نجيب. كل الحقوق محفوظة */}
          <a href="#" className="text-primary font-bold">
            نــجــيــب
          </a>{" "}
          كل الحقوق محفوظة {new Date().getFullYear()} &copy;
        </p>
      </div>
    </footer>
  );
}

export default Footer;
