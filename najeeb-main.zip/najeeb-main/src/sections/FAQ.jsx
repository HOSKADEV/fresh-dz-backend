import { useState } from "react";
import { faqData } from "../data/faq";
import { types } from "../data/faq";
import { FaChevronUp } from "react-icons/fa";
import { FaChevronDown } from "react-icons/fa";
import { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css"; // Import the AOS styles
function FAQ() {
  const [show, setShow] = useState(0);
  const [active, setActive] = useState("student");
  const handleClick = (id) => {
    setShow((prevShow) => (prevShow === id ? 0 : id));
  };
  const fitQuestions = faqData && faqData.filter((faq) => faq.type !== active);
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true, // Affect only the first element in the array
    }); // Initialize AOS with optional settings
  }, []);

  return (
    <section id="overflow-hidden">
      <div
        className="      flex flex-col gap-16 pb-[100px] myContainer
"
      >
        <div className="flex flex-col items-center gap-4">
          <h1 data-aos="zoom-in" className="mainTitle">
            الاسئلة الشائعة
          </h1>
          <p
            data-aos="fade-up"
            data-aos-delay="50"
            className="text-secondary text-center"
          >
            هناك العديد من الأسئلة التي يمكن أن تكون لديك حول تطبيق نجيب
          </p>
        </div>
        <div className="flex gap-4 sm:gap-8 md:w-2/3 lg:1/2 mx-auto justify-center">
          {types.map((type) => {
            return (
              <div
                data-aos={`${type.id % 2 === 0 ? "zoom-in" : "zoom-out"}`}
                data-aos-delay="150"
                key={type.id}
                className=""
              >
                <div
                  className={`
                ${
                  type.title === active
                    ? "border-primary"
                    : " hover:border-border-gray"
                }
                flex flex-col items-center gap-4 p-4
              cursor-pointer hover:scale-105 transiton-all duration-300
              border-2 rounded-md
              
              `}
                  onClick={() => {
                    setActive(type.title);
                  }}
                >
                  <img src={type.img} className="w-44" alt="" />
                  <h1 className="text-2xl "> {type.name} </h1>
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex flex-col items-center gap-12 ">
          {fitQuestions.map((el, key) => {
            return (
              <div
                data-aos="fade-up"
                data-aos-delay={`${100 * key}`}
                style={{ borderRightColor: el.color }}
                key={key}
                className="flex flex-col  p-4 border-r rounded-lg shadow-slate-200  shadow-lg dark:shadow-mydarkShaow w-full md:w-[80%] lg:w-[50%] "
              >
                <div
                  className="flex justify-between items-center cursor-pointer gap-4"
                  onClick={() => {
                    handleClick(el.id);
                  }}
                >
                  <h3 className="text-sm sm:text-lg"> {el.question} </h3>
                  <span style={{ color: el.color }}>
                    {show === el.id ? <FaChevronDown /> : <FaChevronUp />}
                  </span>
                </div>
                {show === el.id && (
                  <p className="pt-8   leading-loose text-secondary dark:text-darksecondary ">
                    {el.answer}{" "}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default FAQ;
