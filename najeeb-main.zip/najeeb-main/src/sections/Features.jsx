import React from "react";
import logoImage from "../Assets/images/logo.svg";
import { featuresData } from "../data/features";
import { MdOndemandVideo } from "react-icons/md";
import AOS from "aos";
import "aos/dist/aos.css"; // Import the AOS styles
import { useEffect } from "react";

function Features() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true, // Affect only the first element in the array
    }); // Initialize AOS with optional settings
  }, []);
  return (
    <section className="features">
      <div className="myContainer flex flex-col justify-center items-center gap-8">
        <div className="flex flex-col items-center gap-4">
          <h1 data-aos="zoom-in" className="mainTitle">
            المميزات
          </h1>
          <p
            data-aos="fade-up"
            data-aos-delay="50"
            className="text-secondary text-center"
          >
            لمادا يجب عليك استخدام تطبيق نجيب للحصول على دروسك اونلاين
          </p>
        </div>
        <div className="flex flex-col lg:flex-row mt-16 gap-16">
          <div className="flex flex-col items-start gap-8 lg:w-1/3 ">
            <span
              data-aos="fade-up"
              className="bg-gray-100 w-16 h-16 p-2 rounded-md flex justify-center items-center"
            >
              <img src={logoImage} alt="logo" />
            </span>
            <h2
              data-aos="fade-up"
              data-aos-delay="100"
              className="text-2xl font-semibold"
            >
              لماذا تطبيق{" "}
              <span className="text-primary font-bold">نــجــيــب</span>؟
            </h2>

            <p
              data-aos="fade-up"
              data-aos-delay="150"
              className="text-secondary leading-loose"
            >
              تطبيق نجيب مصمم لتلبية احتياجات الطلاب والمعلمين على حد سواء. يقدم
              مجموعة متنوعة من الدورات التدريبية عبر الإنترنت في مجالات مختلفة،
              مما يساعد في تحسين المهارات الأكاديمية والعملية. مع فريق من
              المعلمين المحترفين، نحن هنا لدعم رحلة تعلمك وتوفير تجربة تعليمية
              فريدة.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 flex-1 gap-8  ">
            {featuresData.map((feature, index) => {
              return (
                <div
                  data-aos="zoom-in"
                  data-aos-delay={`${100 * index}`}
                  className=""
                >
                  <div
                    className="
                  border-2 relative h-full flex flex-col items-center gap-2 p-4 rounded-md feature"
                  >
                    <div className="spanHolder p-1 rounded-full">
                      <span className="bg-gray-100 b w-16 h-16 rounded-full flex justify-center items-center featurespan">
                        {/* <MdOndemandVideo
                          size={30}
                          className="text-primary g-gray-100 icon"
                        /> */}
                        <feature.icon
                          size={30}
                          className="text-primary g-gray-100 icon"
                        />
                      </span>
                    </div>

                    <h2 className="mt-2 text-lg font-semibold">
                      {" "}
                      {feature.title}{" "}
                    </h2>
                    <p className="text-secondary px-4 md:px-8  text-sm text-center">
                      {feature.content}{" "}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

export default Features;
