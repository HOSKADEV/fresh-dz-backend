export const navLinks = [
  {
    label: "الرئيسية",
    url: "#",
    name: "home",
  },
  {
    label: "المميزات",
    url: "#features",
    name: "features",
  },
  {
    label: "الأسئلة الشائعة",
    url: "#faq",
    name: "faq",
  },
  {
    label: "اتصل بنا",
    url: "#contact",
    name: "contact",
  },
  // {
  //   label: "اتصل بنا",
  //   url: "#contact",
  //   name: "contact",
  // },
];
