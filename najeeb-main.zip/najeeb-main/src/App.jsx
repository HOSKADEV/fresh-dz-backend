import NavBar from "./components/NavBar";
import "./App.css";
import MobileNavBar from "./components/MobileNavBar";
import Hero from "./sections/Hero";
import FAQ from "./sections/FAQ";
import Contact from "./sections/Contact";
import Footer from "./components/Footer";
import Download from "./sections/Download";
import Features from "./sections/Features";
function App() {
  return (
    <>
      <NavBar />
      <MobileNavBar />
      <Hero />
      <Features />
      <FAQ />
      <Download />
      <Contact />
      <Footer />
    </>
  );
}

export default App;
