import React from "react";
import HeroImage from "../Assets/images/najeebHero.jpg";
import { FaGooglePlay } from "react-icons/fa";
import { socialMedia } from "../data/socialMedia";
import AOS from "aos";
import "aos/dist/aos.css"; // Import the AOS styles
import { useEffect } from "react";
function Hero() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true, // Affect only the first element in the array
    }); // Initialize AOS with optional settings
  }, []);
  return (
    <section className="flex flex-col justify-between">
      <div className="myContainer flex flex-col-reverse lg:flex-row lg:items-center h-full py-8 gap-8">
        <div className="flex flex-col items-center lg:items-start flex-1 ">
          <h1
            data-aos-delay="50"
            data-aos="fade-up"
            className=" mainTitle h-24"
          >
            نــجــيــب
          </h1>
          <p
            data-aos="fade-up"
            data-aos-delay="100"
            className=" leading-loose text-secondary text-center lg:text-start "
          >
            نجيب هو تطبيق الكتروني يوفر دورات تدريبية وتكوينية عبر الإنترنت
            لجميع المراحل الدراسية وفي مختلف المجالات، بمشاركة نخبة من المعلمين
            المحترفين. نهدف إلى تزويد الطلاب بفرص تعلم متقدمة تلبي احتياجاتهم
            الأكاديمية والتربوية.
          </p>
          <div data-aos-delay="150" data-aos="fade-up" className="flex">
            <button className="flex gap-2 items-center  text-white px-2.5 py-2 border-none rounded-md my-8">
              <span className="">حمل الان</span>
              <span>
                <FaGooglePlay />
              </span>
            </button>
          </div>
          <div className="flex gap-4">
            {socialMedia.map((el, index) => {
              return (
                <a
                  data-aos="zoom-in"
                  data-aos-delay={`${150 * index}`}
                  key={el.id}
                  href={el.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white text-2xl gap-2"
                >
                  {el.icon}
                </a>
              );
            })}
          </div>
        </div>
        {/* hero image */}
        <div
          data-aos="zoom-in"
          className="flex flex-1 justify-center lg:justify-end"
        >
          <img
            className="max-w-full max-h-full h-96 w-96 lg:w-[500px] lg:h-[500px] rounded-full  border-2 shadow-sm shadow-primary "
            src={HeroImage}
            alt="hero"
          />
        </div>
      </div>

      <div className="mywaves h-16 mt-44 w-full bg-[#3586ff]  p-0 relative  ">
        <div className="mywave" id="wave1">
          {" "}
        </div>
        <div className="mywave" id="wave2">
          {" "}
        </div>
        <div className="mywave" id="wave3">
          {" "}
        </div>
        <div className="mywave" id="wave4">
          {" "}
        </div>
      </div>
    </section>
  );
}

export default Hero;
