import React from "react";
import appImage from "../Assets/images/tarmeez.webp";
import googlePlay from "../Assets/images/GooglePlay.webp";
import { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css"; // Import the AOS styles
function Download() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true, // Affect only the first element in the array
    }); // Initialize AOS with optional settings
  }, []);
  return (
    <div className="myContainer hidden sm:flex justify-center py-20 md:py-24  ">
      <div
        data-aos="fade-up"
        data-aos-delay="150"
        className="flex rounded-lg download w-full lg:w-4/5 2xl:w-3/4 "
      >
        <div className="flex flex-col py-12 px-4 lg:px-8 gap-8 relative w-full">
          <h2 className="text-xl w-72 md:text-3xl leading-loose text-white font-bold pt-8 md:w-96">
            ابدأ دروسك اونلاين من خلال تطبيق نجيب
          </h2>
          <div className="flex gap-4">
            <img
              className="xl:w-72 lg:w-48 w-32 object-fit"
              src={googlePlay}
              alt=""
            />
            <img
              className="xl:w-72 lg:w-48 w-32 object-fit"
              src={googlePlay}
              alt=""
            />
          </div>
          <div className="absolute left-0 bottom-0 ">
            <img className="h-60  md:h-96 lg:h-full" src={appImage} alt="" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Download;
