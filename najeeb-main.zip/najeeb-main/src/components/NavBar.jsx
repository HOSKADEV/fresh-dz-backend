import { navLinks } from "../data/navLinks";
import { useState, useEffect } from "react";
import _ from "lodash";
import logoImage from "../Assets/images/logo.svg";

function NavBar() {
  const [scrollY, setScrollY] = useState(0); // Track vertical scroll position
  const [showNav, setShowNav] = useState(true); // Control visibility of the nav
  const [main, setMain] = useState(""); // Track the currently active nav link
  useEffect(() => {
    // Attach scroll event listener to handle navigation visibility
    const handleScrollTop = () => {
      const scrollTop = window.scrollY;
      setShowNav(scrollTop <= scrollY); // Show/hide nav based on scroll direction
      setScrollY(scrollTop); // Update scroll position
    };

    // Debounce the scroll event to improve performance
    const debouncedHandleScroll = _.debounce(handleScrollTop, 200);
    document.addEventListener("scroll", debouncedHandleScroll); // Attach event listener

    return () => {
      document.removeEventListener("scroll", debouncedHandleScroll); // Cleanup on unmount
    };
  }, [scrollY]);

  return (
    <nav className="h-[70px] hidden lg:flex fixed left-0 right-0 top-0 z-[300]">
      {/* Navigation Bar */}
      {showNav && ( // Render nav only if showNav is true
        <div className="bg-white dark:bg-dark shadow-myShadow dark:shadow-mydarkShaow  w-full">
          <div className="container h-full mx-auto px-4 flex justify-between">
            <a href="/" className="flex items-center gap-4">
              <img className="max-h-[50px]" src={logoImage} alt="Logo" />
              {/* <h2 className="text-2xl font-bold">سوف أكاديمي</h2> */}
            </a>
            <ul className="flex">
              {navLinks.map((link, index) => (
                <li key={index} className="flex m-0">
                  <a
                    href={link.url}
                    className={`navLink text-md font-semibold flex items-center px-6 relative ${
                      main === link.name
                        ? "active" // Active link styling
                        : "text-secondary dark:text-darksecondary hover:text-black dark:hover:text-white"
                    }`}
                    onClick={() => setMain(link.name)} // Set active link on click
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li className="flex items-center">{/* <ThemeSwitcher /> */}</li>
            </ul>
          </div>
        </div>
      )}
    </nav>
  );
}

export default NavBar;
