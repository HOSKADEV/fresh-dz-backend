import { useEffect, useState } from "react";
import _ from "lodash";
import { navLinks } from "../data/navLinks";
import { FaBars } from "react-icons/fa6";
import { IoClose } from "react-icons/io5";
import logoImage from "../Assets/images/logo.svg";

function MobileNavBar() {
  // State management for the mobile navigation
  const [active, setActive] = useState(false); // Toggle the mobile nav visibility
  const [scrollY, setScrollY] = useState(0); // Track vertical scroll position
  const [showNav, setShowNav] = useState(true); // Control the display of the nav bar

  // Effect for handling scroll events
  useEffect(() => {
    const handleScroll = _.debounce(() => {
      const scrollTop = window.scrollY;
      setShowNav(scrollTop <= scrollY); // Show/hide nav based on scroll direction
      setScrollY(scrollTop); // Update scroll position
    }, 200);

    document.addEventListener("scroll", handleScroll); // Attach scroll event listener

    return () => {
      document.removeEventListener("scroll", handleScroll); // Cleanup on component unmount
    };
  }, [scrollY]);

  return (
    <>
      <nav className="h-[70px] lg:hidden sticky left-0 right-0 top-0 z-[300]">
        {/* Logo and Menu Button */}
        {showNav && !active && (
          <div className="h-full shadow-myShadow dark:shadow-mydarkShaow dark:bg-dark bg-white">
            <div className="flex h-full justify-between container mx-auto px-8 md:px-0">
              <a href="/" className="flex items-center gap-4">
                <img className="max-w-12" src={logoImage} alt="Logo" />
              </a>
              <div className="flex items-center">
                <span
                  className="text-2xl text-secondary dark:text-darksecondary cursor-pointer p-1 rounded-lg border dark:border-close-btn-bg"
                  onClick={() => setActive(!active)}
                >
                  <FaBars />
                </span>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Navigation Links */}
      <ul
        className={`${
          active
            ? "opacity-100 scale-100"
            : "scale-0 opacity-0 pointer-events-none"
        } transition-all duration-500 container bg-navbar-bg dark:bg-dark border border-border-gray dark:border-close-btn-bg rounded-md px-4 pt-4 fixed z-[1000] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2`}
      >
        <button
          className="bg-close-btn-bg dark:bg-spdarkbg text-close-btn-text rounded-md flex justify-center items-center w-8 h-8 ms-auto mb-4"
          onClick={() => setActive(false)}
        >
          <IoClose size={22} />
        </button>
        {navLinks.map((link, index) => (
          <li key={index}>
            <a
              href={link.url}
              className={`${
                index !== navLinks.length - 1 ? "border-b" : ""
              } text-secondary dark:text-darksecondary p-4 block hover:text-black dark:hover:text-white`}
              onClick={() => setActive(false)}
            >
              {link.label}
            </a>
          </li>
        ))}
      </ul>

      {/* Overlay for Mobile Nav */}
      <div
        className={`${
          active ? "flex opacity-100" : "opacity-0 pointer-events-none"
        } transition-transform duration-500 ease-linear flex-col items-center justify-center fixed h-screen backdrop-blur-sm z-[301] cursor-pointer left-0 right-0 top-0 bottom-0 bg-overlay-bg/40 dark:bg-overlay-bg/80`}
        onClick={() => setActive(false)}
      ></div>
    </>
  );
}

export default MobileNavBar;
